@echo off
echo Fanthom Installer starting...
echo.

echo Searching for Python...
SET REAL_PYTHON=

IF EXIST "C:\Python313\python.exe" SET REAL_PYTHON=C:\Python313\python.exe & GOTO found_python
IF EXIST "C:\Python312\python.exe" SET REAL_PYTHON=C:\Python312\python.exe & GOTO found_python
IF EXIST "C:\Python311\python.exe" SET REAL_PYTHON=C:\Python311\python.exe & GOTO found_python
IF EXIST "C:\Python310\python.exe" SET REAL_PYTHON=C:\Python310\python.exe & GOTO found_python
IF EXIST "C:\Program Files\Python313\python.exe" SET REAL_PYTHON=C:\Program Files\Python313\python.exe & GOTO found_python
IF EXIST "C:\Program Files\Python312\python.exe" SET REAL_PYTHON=C:\Program Files\Python312\python.exe & GOTO found_python
IF EXIST "C:\Program Files\Python311\python.exe" SET REAL_PYTHON=C:\Program Files\Python311\python.exe & GOTO found_python
IF EXIST "C:\Program Files\Python310\python.exe" SET REAL_PYTHON=C:\Program Files\Python310\python.exe & GOTO found_python
IF EXIST "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" SET REAL_PYTHON=%LOCALAPPDATA%\Programs\Python\Python313\python.exe & GOTO found_python
IF EXIST "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" SET REAL_PYTHON=%LOCALAPPDATA%\Programs\Python\Python312\python.exe & GOTO found_python
IF EXIST "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" SET REAL_PYTHON=%LOCALAPPDATA%\Programs\Python\Python311\python.exe & GOTO found_python

FOR /F "tokens=*" %%i IN ('where python 2^>nul') DO (
    echo %%i | findstr /I "WindowsApps" >nul
    IF ERRORLEVEL 1 SET REAL_PYTHON=%%i & GOTO found_python
)

echo No Python found. Downloading Python 3.12...
SET PY_INSTALLER=%TEMP%\python312.exe
powershell -NoProfile -WindowStyle Hidden -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.8/python-3.12.8-amd64.exe' -OutFile '%PY_INSTALLER%' -UseBasicParsing"
IF NOT EXIST "%PY_INSTALLER%" (
    echo FAILED: Could not download Python
    echo Install manually from https://python.org then re-run
    pause
    exit /b 1
)
echo Installing Python 3.12...
"%PY_INSTALLER%" /quiet InstallAllUsers=1 PrependPath=1 Include_test=0
del "%PY_INSTALLER%" >nul 2>&1
echo Python installed.
timeout /t 3 /nobreak >nul

IF EXIST "C:\Program Files\Python312\python.exe" SET REAL_PYTHON=C:\Program Files\Python312\python.exe & GOTO found_python
IF EXIST "C:\Python312\python.exe" SET REAL_PYTHON=C:\Python312\python.exe & GOTO found_python
IF EXIST "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" SET REAL_PYTHON=%LOCALAPPDATA%\Programs\Python\Python312\python.exe & GOTO found_python

FOR /F "tokens=*" %%i IN ('where python 2^>nul') DO (
    echo %%i | findstr /I "WindowsApps" >nul
    IF ERRORLEVEL 1 SET REAL_PYTHON=%%i & GOTO found_python
)

echo ERROR: Python install failed. Please install from https://python.org and re-run.
pause
exit /b 1

:found_python
echo Found Python: %REAL_PYTHON%

IF EXIST "%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe" del /F "%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe" >nul 2>&1
IF EXIST "%LOCALAPPDATA%\Microsoft\WindowsApps\python3.exe" del /F "%LOCALAPPDATA%\Microsoft\WindowsApps\python3.exe" >nul 2>&1

FOR %%F IN ("%REAL_PYTHON%") DO SET PY_DIR=%%~dpF
SET REAL_PYTHONW=%PY_DIR%pythonw.exe
IF NOT EXIST "%REAL_PYTHONW%" SET REAL_PYTHONW=%REAL_PYTHON%

SET INSTALL_DIR=C:\ProgramData\FanthomAgent
echo Installing to %INSTALL_DIR%...
IF NOT EXIST "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

echo Installing dependencies...
"%REAL_PYTHON%" -m pip install -r "%~dp0requirements-agent.txt" --upgrade --quiet
echo Dependencies installed.

echo Installing pywin32 for Windows Service...
"%REAL_PYTHON%" -m pip install pywin32 --upgrade --quiet
"%REAL_PYTHON%" "%PY_DIR%Scripts\pywin32_postinstall.py" -install >nul 2>&1
echo pywin32 installed.

echo Copying agent files...
copy /Y "%~dp0agent\fanthom_node.py" "%INSTALL_DIR%\" >nul
copy /Y "%~dp0agent\fanthom_supervisor.py" "%INSTALL_DIR%\" >nul
copy /Y "%~dp0agent\fanthom_service.py" "%INSTALL_DIR%\" >nul
copy /Y "%~dp0agent\fanthom_runtime.py" "%INSTALL_DIR%\" >nul
copy /Y "%~dp0agent\telemetry_agent.py" "%INSTALL_DIR%\" >nul
copy /Y "%~dp0agent\config.json" "%INSTALL_DIR%\" >nul
echo %REAL_PYTHON%> "%INSTALL_DIR%\pythonw_path.txt"
echo Files copied.

echo Installing Windows Service...
sc stop FanthomAgent >nul 2>&1
sc delete FanthomAgent >nul 2>&1
timeout /t 2 /nobreak >nul

"%REAL_PYTHON%" "%INSTALL_DIR%\fanthom_service.py" install >nul 2>&1
IF ERRORLEVEL 1 (
    echo Service install failed - using startup folder instead...
    GOTO fallback_startup
)

sc config FanthomAgent start= auto >nul
sc start FanthomAgent >nul 2>&1
timeout /t 3 /nobreak >nul

sc query FanthomAgent | findstr /I "RUNNING" >nul
IF ERRORLEVEL 1 (
    echo Service did not start - using startup folder instead...
    sc delete FanthomAgent >nul 2>&1
    GOTO fallback_startup
)

echo.
echo Fanthom installed as a Windows Service.
echo Runs automatically for ALL users on this machine.
echo Logs: %INSTALL_DIR%\agent.log
echo.
pause
exit /b 0

:fallback_startup
echo Using startup folder for current user...
SET VBS=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\FanthomAgent.vbs
echo CreateObject("WScript.Shell").Run Chr(34) ^& "%REAL_PYTHONW%" ^& Chr(34) ^& " " ^& Chr(34) ^& "%INSTALL_DIR%\fanthom_supervisor.py" ^& Chr(34), 0, False > "%VBS%"
start /B "" "%REAL_PYTHONW%" "%INSTALL_DIR%\fanthom_supervisor.py"
echo.
echo Fanthom installed for current user only.
echo Logs: %INSTALL_DIR%\agent.log
echo.
pause
exit /b 0
