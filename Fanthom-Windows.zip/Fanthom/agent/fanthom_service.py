"""
fanthom_service.py - Fanthom Windows Service
Runs as SYSTEM at boot. Launches fanthom_supervisor.py in the active
user session so KB/mouse monitoring works correctly.
Only ever runs ONE supervisor instance at a time.
"""
import sys
import time
import pathlib
import subprocess

try:
    import win32serviceutil
    import win32service
    import win32event
    import win32ts
    import win32process
    import win32profile
    import win32security
    import win32api
    import win32con
    import servicemanager
    HAS_WIN32 = True
except ImportError:
    HAS_WIN32 = False

INSTALL_DIR = pathlib.Path(__file__).resolve().parent
SUPERVISOR  = str(INSTALL_DIR / "fanthom_supervisor.py")
PYTHON_FILE = INSTALL_DIR / "pythonw_path.txt"
PYTHON      = PYTHON_FILE.read_text().strip() if PYTHON_FILE.exists() else sys.executable
LOG         = str(INSTALL_DIR / "fanthom_service.log")


def log(msg):
    from datetime import datetime
    line = f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} {msg}\n"
    try:
        with open(LOG, "a") as f:
            f.write(line)
    except Exception:
        pass


def is_process_running(pid):
    """Check if a PID is still alive."""
    if not pid:
        return False
    try:
        h = win32api.OpenProcess(win32con.PROCESS_QUERY_INFORMATION, False, pid)
        code = win32process.GetExitCodeProcess(h)
        win32api.CloseHandle(h)
        return code == 259  # 259 = STILL_ACTIVE
    except Exception:
        return False


def launch_in_user_session():
    """Launch supervisor in the active user session. Returns PID or False."""
    try:
        session_id = win32ts.WTSGetActiveConsoleSessionId()
        if session_id == 0xFFFFFFFF:
            log("No active user session")
            return False
        token = win32ts.WTSQueryUserToken(session_id)
        env = win32profile.CreateEnvironmentBlock(token, False)
        cmd = f'"{PYTHON}" "{SUPERVISOR}"'
        startup = win32process.STARTUPINFO()
        startup.dwFlags = win32con.STARTF_USESHOWWINDOW
        startup.wShowWindow = win32con.SW_HIDE
        proc_info = win32process.CreateProcessAsUser(
            token, None, cmd, None, None, False,
            win32con.CREATE_NO_WINDOW | win32con.CREATE_UNICODE_ENVIRONMENT,
            env, str(INSTALL_DIR), startup
        )
        pid = proc_info[2]
        log(f"Launched supervisor in user session - PID {pid}")
        win32api.CloseHandle(proc_info[0])
        win32api.CloseHandle(proc_info[1])
        token.Close()
        return pid
    except Exception as e:
        log(f"Failed to launch in user session: {e}")
        return False


class FanthomService(win32serviceutil.ServiceFramework):
    _svc_name_         = "FanthomAgent"
    _svc_display_name_ = "Fanthom Agent"
    _svc_description_  = "Fanthom endpoint telemetry agent"

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.stop_event = win32event.CreateEvent(None, 0, 0, None)
        self.running = True

    def SvcStop(self):
        log("Service stop requested")
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        self.running = False
        win32event.SetEvent(self.stop_event)

    def SvcDoRun(self):
        log("=" * 40)
        log("Fanthom Service started")
        servicemanager.LogMsg(
            servicemanager.EVENTLOG_INFORMATION_TYPE,
            servicemanager.PYS_SERVICE_STARTED,
            (self._svc_name_, "")
        )

        # Wait for system to finish booting
        time.sleep(10)

        current_pid = None

        while self.running:
            try:
                if is_process_running(current_pid):
                    # Supervisor is alive - do nothing
                    pass
                else:
                    if current_pid:
                        log("Supervisor exited - relaunching...")
                    current_pid = None
                    result = launch_in_user_session()
                    if result:
                        current_pid = result
                    else:
                        # No user session yet - retry in 30s
                        win32event.WaitForSingleObject(self.stop_event, 30000)
                        continue
            except Exception as e:
                log(f"Service loop error: {e}")

            # Check every 30 seconds
            win32event.WaitForSingleObject(self.stop_event, 30000)

        log("Fanthom Service stopped")


if __name__ == "__main__":
    if HAS_WIN32:
        win32serviceutil.HandleCommandLine(FanthomService)
    else:
        print("pywin32 not available")
        sys.exit(1)
