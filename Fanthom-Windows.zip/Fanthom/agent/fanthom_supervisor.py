"""
fanthom_supervisor.py - Fanthom Supervisor
Keeps fanthom_node.py running, restarts it if it crashes.
Runs as a Windows Service via NSSM or from startup folder.
"""
import subprocess
import sys
import time
import pathlib
from datetime import datetime

INSTALL_DIR = pathlib.Path(__file__).resolve().parent
AGENT       = str(INSTALL_DIR / "fanthom_node.py")
CONFIG      = str(INSTALL_DIR / "config.json")
LOG         = str(INSTALL_DIR / "fanthom_supervisor.log")
AGENT_LOG   = str(INSTALL_DIR / "agent.log")

# Use python from pythonw_path.txt if available, else current interpreter
PYTHON_PATH_FILE = INSTALL_DIR / "pythonw_path.txt"
if PYTHON_PATH_FILE.exists():
    PYTHON = PYTHON_PATH_FILE.read_text().strip()
else:
    PYTHON = sys.executable


def log(msg):
    line = f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} {msg}"
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass
    print(line, flush=True)


log("=" * 50)
log("Fanthom Supervisor started")
log(f"Agent:  {AGENT}")
log(f"Python: {PYTHON}")
log("=" * 50)
log("Waiting 10 seconds for system startup...")
time.sleep(10)
log("Starting now...")

delay = 5

while True:
    try:
        log("Starting agent...")
        with open(AGENT_LOG, "a", encoding="utf-8") as agent_log_f:
            proc = subprocess.Popen(
                [PYTHON, AGENT, "--config", CONFIG],
                stdout=agent_log_f,
                stderr=subprocess.STDOUT,
            )
        log(f"Agent running - PID {proc.pid}")
        proc.wait()
        log(f"Agent exited with code {proc.returncode} - restarting in {delay}s")
    except Exception as e:
        log(f"Supervisor error: {e} - restarting in {delay}s")
    time.sleep(delay)
