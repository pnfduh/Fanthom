@echo off
echo Fanthom Uninstaller...
echo.

echo Stopping service...
sc stop FanthomAgent >nul 2>&1
sc delete FanthomAgent >nul 2>&1
echo Service removed.

echo Removing startup entry...
SET VBS_FILE=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\FanthomAgent.vbs
IF EXIST "%VBS_FILE%" del /F "%VBS_FILE%" >nul 2>&1
echo Startup entry removed.

echo Removing agent files...
rmdir /S /Q "C:\ProgramData\FanthomAgent" >nul 2>&1
rmdir /S /Q "%APPDATA%\FanthomAgent" >nul 2>&1
echo Files removed.

echo.
echo Fanthom has been fully uninstalled.
echo.
pause
