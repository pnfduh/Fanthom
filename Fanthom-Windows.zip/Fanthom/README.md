# Installation

1. Download this repository as a ZIP and extract it
2. Right-click `Fanthom Installer.bat`
3. Select **Run as administrator**
4. Click **Yes** on the UAC prompt
5. Wait for the installer to complete

That's it.

---

**To uninstall:**
Right-click `Fanthom Uninstaller.bat` and select **Run as administrator**
