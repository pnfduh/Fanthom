#!/bin/bash
PLIST_PATH="$HOME/Library/LaunchAgents/com.fathom.agent.plist"
AGENT_DIR="$HOME/Library/Application Support/FathomAgent"

echo "Removing Fathom..."
launchctl unload "$PLIST_PATH" 2>/dev/null || true
rm -f "$PLIST_PATH"
rm -rf "$AGENT_DIR"
echo "Fathom uninstalled."
