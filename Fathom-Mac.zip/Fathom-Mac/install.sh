#!/bin/bash
# ================================================
#  Fathom Installer — macOS
#  Installs agent and registers LaunchAgent
#  for auto-start at login
# ================================================

set -e

AGENT_DIR="$HOME/Library/Application Support/FathomAgent"
PLIST_DIR="$HOME/Library/LaunchAgents"
PLIST_PATH="$PLIST_DIR/com.fathom.agent.plist"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo ""
echo "Fathom Installer"
echo "================"
echo ""

# ── Step 1: Check for Python ──────────────────
echo "[*] Checking for Python..."
PYTHON=""

for candidate in python3 /usr/local/bin/python3 /opt/homebrew/bin/python3 /usr/bin/python3; do
    if command -v "$candidate" &>/dev/null; then
        VER=$("$candidate" --version 2>&1 | awk '{print $2}')
        MAJOR=$(echo "$VER" | cut -d. -f1)
        MINOR=$(echo "$VER" | cut -d. -f2)
        if [ "$MAJOR" -ge 3 ] && [ "$MINOR" -ge 9 ]; then
            PYTHON="$candidate"
            echo "[✓] Found Python $VER at $PYTHON"
            break
        fi
    fi
done

if [ -z "$PYTHON" ]; then
    echo "[!] Python 3.9+ not found."
    echo "    Installing via Homebrew..."
    if ! command -v brew &>/dev/null; then
        echo "[*] Installing Homebrew first..."
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
        # Add brew to PATH for Apple Silicon
        if [ -f /opt/homebrew/bin/brew ]; then
            eval "$(/opt/homebrew/bin/brew shellenv)"
        fi
    fi
    brew install python3
    PYTHON=$(command -v python3)
    echo "[✓] Python installed at $PYTHON"
fi

# ── Step 2: Create install directory ─────────
echo "[*] Creating install directory..."
mkdir -p "$AGENT_DIR"
echo "[✓] $AGENT_DIR"

# ── Step 3: Copy agent files ──────────────────
echo "[*] Copying agent files..."
cp -r "$SCRIPT_DIR/agent/"* "$AGENT_DIR/"
echo "[✓] Files copied."

# ── Step 4: Install dependencies ─────────────
echo "[*] Installing Python dependencies..."
"$PYTHON" -m pip install --quiet --upgrade websockets psutil pyobjc-framework-Quartz 2>/dev/null || \
"$PYTHON" -m pip install --quiet --upgrade --user websockets psutil pyobjc-framework-Quartz
echo "[✓] Dependencies installed."

# ── Step 5: Write LaunchAgent plist ──────────
echo "[*] Writing LaunchAgent..."
mkdir -p "$PLIST_DIR"

cat > "$PLIST_PATH" << PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.fathom.agent</string>
    <key>ProgramArguments</key>
    <array>
        <string>$PYTHON</string>
        <string>$AGENT_DIR/fathom_supervisor.py</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>$AGENT_DIR/stdout.log</string>
    <key>StandardErrorPath</key>
    <string>$AGENT_DIR/stderr.log</string>
    <key>WorkingDirectory</key>
    <string>$AGENT_DIR</string>
</dict>
</plist>
PLIST

echo "[✓] LaunchAgent written to $PLIST_PATH"

# ── Step 6: Load LaunchAgent ──────────────────
echo "[*] Loading LaunchAgent..."
launchctl unload "$PLIST_PATH" 2>/dev/null || true
launchctl load "$PLIST_PATH"
echo "[✓] Agent loaded and running."

echo ""
echo "================================================"
echo "  Fathom installed successfully!"
echo "  Agent runs silently at every login."
echo ""
echo "  Logs: $AGENT_DIR/fathom_supervisor.log"
echo "  To uninstall: run uninstall.sh"
echo "================================================"
echo ""
