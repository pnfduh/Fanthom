# Installation

1. Download and unzip this file
2. Open Terminal
3. Run:
   ```
   bash "Fathom Installer.sh"
   ```
4. Wait for the installer to complete

The agent will start automatically and run in the background at every login.

---

**To uninstall:**
```
bash "Fathom Uninstaller.sh"
```
