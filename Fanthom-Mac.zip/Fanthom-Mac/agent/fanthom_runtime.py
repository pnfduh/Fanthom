"""
fanthom_runtime.py — System metrics for Fanthom agent.

Collects:
  • CPU, RAM, Disk usage %
  • Network bytes sent/recv (delta per interval)
  • Battery status
  • Top 5 processes by CPU
  • System uptime
  • Static device info
"""

import platform
import socket
import time
import logging
from datetime import datetime, timezone

import psutil

logger = logging.getLogger(__name__)

_device_info_cache: dict | None = None
_last_net = None
_last_net_time = None


def get_device_info() -> dict:
    global _device_info_cache
    if _device_info_cache is not None:
        return _device_info_cache
    ip = "unknown"
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
    except Exception:
        try:
            ip = socket.gethostbyname(socket.gethostname())
        except Exception:
            pass
    uname = platform.uname()
    _device_info_cache = {
        "hostname":   socket.gethostname(),
        "os_version": f"{uname.system} {uname.release} ({uname.version[:40]})",
        "ip_address": ip,
        "username":   _get_username(),
    }
    return _device_info_cache


def _get_username() -> str:
    try:
        import getpass
        return getpass.getuser()
    except Exception:
        return "unknown"


def _get_network_delta() -> dict:
    global _last_net, _last_net_time
    try:
        now   = time.monotonic()
        stats = psutil.net_io_counters()
        if _last_net is None:
            _last_net      = stats
            _last_net_time = now
            return {"net_sent_kbps": 0.0, "net_recv_kbps": 0.0}
        elapsed = max(now - _last_net_time, 0.001)
        sent_kbps = round((stats.bytes_sent - _last_net.bytes_sent) / elapsed / 1024, 1)
        recv_kbps = round((stats.bytes_recv - _last_net.bytes_recv) / elapsed / 1024, 1)
        _last_net      = stats
        _last_net_time = now
        return {
            "net_sent_kbps": max(sent_kbps, 0),
            "net_recv_kbps": max(recv_kbps, 0),
        }
    except Exception:
        return {"net_sent_kbps": 0.0, "net_recv_kbps": 0.0}


def _get_battery() -> dict:
    try:
        b = psutil.sensors_battery()
        if b is None:
            return {"battery_percent": None, "battery_plugged": None}
        return {
            "battery_percent": round(b.percent, 1),
            "battery_plugged": b.power_plugged,
        }
    except Exception:
        return {"battery_percent": None, "battery_plugged": None}


def _get_top_processes(n=5) -> list:
    try:
        procs = []
        for p in psutil.process_iter(['name', 'cpu_percent', 'memory_percent']):
            try:
                procs.append({
                    "name": p.info['name'],
                    "cpu":  round(p.info['cpu_percent'] or 0, 1),
                    "mem":  round(p.info['memory_percent'] or 0, 1),
                })
            except Exception:
                pass
        procs.sort(key=lambda x: x['cpu'], reverse=True)
        return procs[:n]
    except Exception:
        return []


def get_system_metrics() -> dict:
    cpu    = psutil.cpu_percent(interval=None)
    vm     = psutil.virtual_memory()
    net    = _get_network_delta()
    batt   = _get_battery()
    top    = _get_top_processes()

    try:
        disk = psutil.disk_usage("/")
    except Exception:
        disk = None

    return {
        "cpu_percent":    round(cpu, 1),
        "ram_percent":    round(vm.percent, 1),
        "ram_used_gb":    round(vm.used / 1e9, 2),
        "ram_total_gb":   round(vm.total / 1e9, 2),
        "disk_percent":   round(disk.percent, 1) if disk else 0.0,
        "disk_used_gb":   round(disk.used / 1e9, 1) if disk else 0.0,
        "disk_total_gb":  round(disk.total / 1e9, 1) if disk else 0.0,
        "net_sent_kbps":  net["net_sent_kbps"],
        "net_recv_kbps":  net["net_recv_kbps"],
        "battery_percent": batt["battery_percent"],
        "battery_plugged": batt["battery_plugged"],
        "top_processes":  top,
        "uptime_seconds": int(time.time() - psutil.boot_time()),
        "ts": datetime.now(timezone.utc).isoformat(),
    }
