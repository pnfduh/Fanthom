"""
telemetry_agent.py — Input activity monitoring for Fanthom agent.

Tracks:
  - Keyboard EPM (events per minute, rolling 10s window)
  - Mouse EPM (clicks only, rolling 10s window)
  - Cumulative totals (keyboard presses, mouse clicks) since agent start
  - Idle time
  - Active window / app / browser
"""

import os
import sys
import time
import threading
import subprocess
import re
from datetime import datetime, timezone

import logging
logger = logging.getLogger(__name__)

# ── Constants ──────────────────────────────────────────────────────────────────
WINDOW_SECONDS = 10       # EPM rolling window
BROWSER_PROCESSES = {"chrome", "firefox", "msedge", "safari", "opera", "brave"}
BROWSER_DISPLAY_NAMES = {
    "chrome": "Google Chrome", "firefox": "Mozilla Firefox",
    "msedge": "Microsoft Edge", "safari": "Safari",
    "opera": "Opera", "brave": "Brave",
}

# ── Global shared state ────────────────────────────────────────────────────────
_lock              = threading.Lock()
_kb_times:    list = []      # timestamps of recent key events
_mouse_times: list = []      # timestamps of recent click events
_kb_total:    int  = 0       # cumulative key presses
_mouse_total: int  = 0       # cumulative mouse clicks
_last_event_time: float = time.monotonic()

# Keystroke stream — last 200 chars of typed text, cleared on idle
_keystroke_buffer: list = []   # list of (timestamp, display_str)
_KEYSTROKE_WINDOW  = 30        # seconds to keep keystrokes visible
_last_app: str = ""            # detect app switches

# Callback to notify the agent of new input (set by fanthom_node)
_on_input_callback = None

def set_input_callback(fn):
    global _on_input_callback
    _on_input_callback = fn

def _notify_input():
    if _on_input_callback:
        try:
            _on_input_callback()
        except Exception:
            pass

# ── Input event recorders ──────────────────────────────────────────────────────

def record_key_press(key_str: str = "·"):
    global _kb_total, _last_event_time
    now = time.monotonic()
    with _lock:
        _kb_times.append(now)
        _kb_total += 1
        _last_event_time = now
        # Keep rolling keystroke buffer (last 30s)
        _keystroke_buffer.append((now, key_str))
        cutoff = now - _KEYSTROKE_WINDOW
        while _keystroke_buffer and _keystroke_buffer[0][0] < cutoff:
            _keystroke_buffer.pop(0)
    _notify_input()

def record_mouse_click():
    global _mouse_total, _last_event_time
    now = time.monotonic()
    with _lock:
        _mouse_times.append(now)
        _mouse_total += 1
        _last_event_time = now
    _notify_input()

# ── Rate calculation ───────────────────────────────────────────────────────────

def get_activity_rates() -> dict:
    now    = time.monotonic()
    cutoff = now - WINDOW_SECONDS
    with _lock:
        kb_recent    = [t for t in _kb_times    if t > cutoff]
        mouse_recent = [t for t in _mouse_times if t > cutoff]
        # prune in place
        _kb_times[:]    = kb_recent
        _mouse_times[:] = mouse_recent
        kb_count    = len(kb_recent)
        ms_count    = len(mouse_recent)
        idle        = now - _last_event_time
        kb_tot      = _kb_total
        ms_tot      = _mouse_total

    # Build recent keystroke string
    now2 = time.monotonic()
    cutoff2 = now2 - _KEYSTROKE_WINDOW
    with _lock:
        recent_keys = "".join(s for t, s in _keystroke_buffer if t > cutoff2)

    scale = 60.0 / WINDOW_SECONDS
    return {
        "keyboard_events_per_min": round(kb_count * scale),
        "mouse_events_per_min":    round(ms_count * scale),
        "keyboard_total":          kb_tot,
        "mouse_total":             ms_tot,
        "idle_seconds":            round(idle, 1),
        "recent_keystrokes":       recent_keys[-300:],  # last 300 chars
    }

# ── Window / app detection ─────────────────────────────────────────────────────

def get_active_window() -> tuple[str, str]:
    """Returns (window_title, process_name). Mac implementation using AppleScript."""
    try:
        import subprocess
        script = '''
        tell application "System Events"
            set frontApp to name of first application process whose frontmost is true
        end tell
        tell application frontApp
            try
                set windowTitle to name of front window
            on error
                set windowTitle to ""
            end try
        end tell
        return frontApp & "|" & windowTitle
        '''
        result = subprocess.run(
            ['osascript', '-e', script],
            capture_output=True, text=True, timeout=2
        )
        if result.returncode == 0 and '|' in result.stdout:
            parts = result.stdout.strip().split('|', 1)
            proc_name = parts[0].strip()
            title     = parts[1].strip() if len(parts) > 1 else ''
            return title, proc_name
    except Exception:
        pass
    return "", ""

def get_running_browser() -> str:
    try:
        import psutil
        for proc in psutil.process_iter(['name']):
            name = proc.info['name'].lower().replace('.exe', '')
            if name in BROWSER_PROCESSES:
                return BROWSER_DISPLAY_NAMES.get(name, name)
    except Exception:
        pass
    return ""

def _extract_domain_from_title(title: str) -> str:
    patterns = [
        r'(?:https?://)?(?:www\.)?([a-zA-Z0-9-]+\.[a-zA-Z]{2,})',
        r'[-–—]\s*([a-zA-Z0-9-]+\.[a-zA-Z]{2,})\s*$',
    ]
    for p in patterns:
        m = re.search(p, title)
        if m:
            return m.group(1)
    return ""

def get_activity_metrics() -> dict:
    title, proc_name = get_active_window()
    rates = get_activity_rates()

    clean_proc      = proc_name.lower().replace(".exe", "")
    browser_process = ""
    browser_domain  = ""

    if clean_proc in BROWSER_PROCESSES:
        browser_process = BROWSER_DISPLAY_NAMES.get(clean_proc, clean_proc)
        browser_domain  = _extract_domain_from_title(title)
    else:
        running = get_running_browser()
        if running:
            browser_process = f"{running} (background)"

    return {
        "active_window_title":     title[:120] if title else "",
        "active_app":              proc_name[:64] if proc_name else "",
        "keyboard_events_per_min": rates["keyboard_events_per_min"],
        "mouse_events_per_min":    rates["mouse_events_per_min"],
        "keyboard_total":          rates["keyboard_total"],
        "mouse_total":             rates["mouse_total"],
        "idle_seconds":            rates["idle_seconds"],
        "recent_keystrokes":       rates.get("recent_keystrokes", ""),
        "browser_process":         browser_process,
        "browser_domain":          browser_domain,
        "ts": datetime.now(timezone.utc).isoformat(),
    }

# ── Input listeners ────────────────────────────────────────────────────────────

def start_input_listeners():
    """Start pynput listeners for accurate key + click counting."""
    try:
        from pynput import keyboard as _kb_mod, mouse as _mouse_mod

        def on_press(key):
            try:
                # Regular printable character
                ch = key.char
                if ch and ch.isprintable():
                    record_key_press(ch)
                else:
                    record_key_press("·")
            except AttributeError:
                # Special key
                special = {
                    _kb_mod.Key.space:     " ",
                    _kb_mod.Key.enter:     "↵",
                    _kb_mod.Key.backspace:  "⌫",
                    _kb_mod.Key.tab:       "⇥",
                    _kb_mod.Key.delete:    "⌦",
                    _kb_mod.Key.esc:       "[ESC]",
                    _kb_mod.Key.caps_lock: "[CAPS]",
                    _kb_mod.Key.shift:     "",
                    _kb_mod.Key.shift_r:   "",
                    _kb_mod.Key.ctrl_l:    "",
                    _kb_mod.Key.ctrl_r:    "",
                    _kb_mod.Key.alt_l:     "",
                    _kb_mod.Key.alt_r:     "",
                    _kb_mod.Key.cmd:       "",
                    _kb_mod.Key.left:      "←",
                    _kb_mod.Key.right:     "→",
                    _kb_mod.Key.up:        "↑",
                    _kb_mod.Key.down:      "↓",
                }
                display = special.get(key, "")
                record_key_press(display)

        def on_click(x, y, button, pressed):
            if pressed:
                record_mouse_click()

        kb_listener    = _kb_mod.Listener(on_press=on_press, daemon=True)
        mouse_listener = _mouse_mod.Listener(on_click=on_click, daemon=True)
        kb_listener.start()
        mouse_listener.start()
        logger.info("pynput listeners started (keyboard + mouse clicks)")
        return True
    except Exception as e:
        logger.warning("pynput unavailable (%s) — falling back to polling", e)
        _start_fallback_poller()
        return False

def _start_fallback_poller():
    """Fallback for Mac: iokit idle time polling."""
    def _poll():
        import subprocess
        last_idle = 0
        while True:
            try:
                r = subprocess.run(
                    ['ioreg', '-c', 'IOHIDSystem'],
                    capture_output=True, text=True, timeout=2
                )
                for line in r.stdout.splitlines():
                    if 'HIDIdleTime' in line:
                        ns = int(line.split('=')[-1].strip())
                        idle_s = ns / 1e9
                        if idle_s < last_idle:
                            record_key_press()
                        last_idle = idle_s
                        break
            except Exception:
                pass
            time.sleep(0.25)

    t = threading.Thread(target=_poll, daemon=True)
    t.start()
    logger.info("Fallback input poller started (Mac iokit)")
