#!/bin/bash
# ============================================================
#  Fanthom Installer — macOS
#  Supports Intel (x86_64) and Apple Silicon (M1/M2/M3)
#  Run with: bash "Fanthom Installer.sh"
# ============================================================

set -e

INSTALL_DIR="$HOME/Library/Application Support/FanthomAgent"
PLIST_DIR="$HOME/Library/LaunchAgents"
PLIST_FILE="$PLIST_DIR/site.fanthom.agent.plist"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REQUIREMENTS="$SCRIPT_DIR/requirements-agent.txt"
AGENT_DIR="$SCRIPT_DIR/agent"

echo ""
echo "Fanthom Installer (macOS)"
echo "========================"
echo ""

# ── Step 1: Find or install Python ──────────────────────────────────────────
echo "[*] Checking for Python 3..."

PYTHON=""

# Check common locations
for candidate in \
    "/usr/local/bin/python3" \
    "/opt/homebrew/bin/python3" \
    "/usr/bin/python3" \
    "$(which python3 2>/dev/null)"; do
    if [ -x "$candidate" ]; then
        version=$("$candidate" --version 2>&1 | grep -oE '[0-9]+\.[0-9]+' | head -1)
        major=$(echo "$version" | cut -d. -f1)
        minor=$(echo "$version" | cut -d. -f2)
        if [ "$major" -ge 3 ] && [ "$minor" -ge 9 ]; then
            PYTHON="$candidate"
            break
        fi
    fi
done

if [ -z "$PYTHON" ]; then
    echo "[*] Python 3.9+ not found. Installing via Homebrew..."

    # Install Homebrew if not present
    if ! command -v brew &>/dev/null; then
        echo "[*] Installing Homebrew..."
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
        # Add brew to path for Apple Silicon
        if [ -f "/opt/homebrew/bin/brew" ]; then
            export PATH="/opt/homebrew/bin:$PATH"
        fi
    fi

    brew install python3
    PYTHON="$(which python3)"
fi

echo "[✓] Using Python: $PYTHON ($($PYTHON --version))"
echo ""

# ── Step 2: Install dependencies ────────────────────────────────────────────
echo "[*] Installing dependencies..."
"$PYTHON" -m pip install -r "$REQUIREMENTS" --quiet --upgrade
echo "[✓] Dependencies installed."
echo ""

# ── Step 3: Copy agent files ─────────────────────────────────────────────────
echo "[*] Installing agent to: $INSTALL_DIR"
mkdir -p "$INSTALL_DIR"
cp -r "$AGENT_DIR/"* "$INSTALL_DIR/"
echo "[✓] Agent files copied."
echo ""

# ── Step 4: Write LaunchAgent plist ─────────────────────────────────────────
echo "[*] Registering LaunchAgent..."
mkdir -p "$PLIST_DIR"

cat > "$PLIST_FILE" << PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>site.fanthom.agent</string>
    <key>ProgramArguments</key>
    <array>
        <string>$PYTHON</string>
        <string>$INSTALL_DIR/fanthom_supervisor.py</string>
    </array>
    <key>WorkingDirectory</key>
    <string>$INSTALL_DIR</string>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>$INSTALL_DIR/launchagent.log</string>
    <key>StandardErrorPath</key>
    <string>$INSTALL_DIR/launchagent.log</string>
    <key>ThrottleInterval</key>
    <integer>10</integer>
</dict>
</plist>
PLIST

echo "[✓] LaunchAgent plist written."
echo ""

# ── Step 5: Load LaunchAgent ─────────────────────────────────────────────────
echo "[*] Starting Fanthom agent..."

# Unload existing if running
launchctl unload "$PLIST_FILE" 2>/dev/null || true

# Load and start
launchctl load -w "$PLIST_FILE"
sleep 3

# Verify running
if launchctl list | grep -q "site.fanthom.agent"; then
    echo "[✓] Agent is running."
else
    echo "[!] Agent may not have started. Check logs at:"
    echo "    $INSTALL_DIR/launchagent.log"
fi

echo ""
echo "================================================"
echo " Fanthom installed successfully."
echo ""
echo " Agent runs silently in the background."
echo " Starts automatically at every login."
echo ""
echo " Logs: $INSTALL_DIR/fanthom_supervisor.log"
echo "================================================"
echo ""
