#!/bin/bash
# ============================================================
#  Fanthom Uninstaller — macOS
# ============================================================

INSTALL_DIR="$HOME/Library/Application Support/FanthomAgent"
PLIST_FILE="$HOME/Library/LaunchAgents/site.fanthom.agent.plist"

echo ""
echo "Fanthom Uninstaller (macOS)"
echo "=========================="
echo ""

echo "[*] Stopping agent..."
launchctl unload "$PLIST_FILE" 2>/dev/null && echo "[✓] Agent stopped." || echo "[!] Agent was not running."

echo "[*] Removing LaunchAgent..."
rm -f "$PLIST_FILE"
echo "[✓] LaunchAgent removed."

echo "[*] Removing agent files..."
rm -rf "$INSTALL_DIR"
echo "[✓] Agent files removed."

echo ""
echo "Fanthom has been fully uninstalled."
echo ""
